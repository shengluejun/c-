﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class Staffmenu
    {
        private static ToolLibrarySystem ToolLibrarySystem = new ToolLibrarySystem();

        private static string Garden;
        public static string GARDEN => Garden;

        private static string Floor;
        public static string FLOOR => Floor;

        private static string Fence;
        public static string FENCE => Fence;

        private static string Measure;
        public static string MEASURE => Measure;

        private static string Clean;
        public static string CLEAN => Clean;

        private static string Paint;
        public static string PAINT => Paint;

        private static string Electron;
        public static string ELECTRON => Electron;

        private static string Electricity;
        public static string ELECTRICITY => Electricity;

        private static string Automative;
        public static string AUTOMATIVE=>Automative;

        private static string Addinput;
        public static string ADDINPUT => Addinput;

        private static string Deletinput;
        public static string DELETINPUT => Deletinput;  

        public static void staffmenu()
        {
            string uinput;
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Staff Menu+++++++++");
            Console.WriteLine("1. Add a new tool");
            Console.WriteLine("2. Add new pieces of an existing tool");
            Console.WriteLine("3. Remove some pieces of a tool");
            Console.WriteLine("4. Register a new member");
            Console.WriteLine("5. Remove a member");
            Console.WriteLine("6. Find the contact memeber of a member");
            Console.WriteLine("0. Return to main menu");
            Console.WriteLine("==========Please input here==========");
            uinput = Console.ReadLine();
            if (uinput == "1")
            {
                AddNewTool();
            }
            else if (uinput == "2")
            {
                AddNewpiece();
            }
            else if (uinput == "3")
            {
                Removetool();
            }
            else if (uinput == "4")
            {
                Registermember();
            }
            else if (uinput == "5")
            {
                Removemember();
            }
            else if (uinput == "6")
            {
                Findphone();
            }
            else if (uinput == "0")
            {
                Program.MainMenu();
            }
            else { Console.WriteLine("Wrong input try again"); staffmenu();  }
        }

        public static void AddNewTool()
        {
            string uinput;
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Add a New Tool+++++++++");
            Console.WriteLine("1.Gardening tools");
            Console.WriteLine("2.Flooring tools");
            Console.WriteLine("3.Fencing tools");
            Console.WriteLine("4.Measuring tools");
            Console.WriteLine("5.Cleaning tools");
            Console.WriteLine("6.Painting tools");
            Console.WriteLine("7.Electronic tools");
            Console.WriteLine("8.Electricity tools");
            Console.WriteLine("9.Automotive tools");
            Console.WriteLine("0.Back to previous menu");

            uinput = Console.ReadLine();

            if (uinput == "1")
            {
                Gardeningtool();
            }
            else if (uinput == "2")
            {
                Flooringtool();
            }
            else if (uinput == "3")
            {
                Fencingtool();
            }
            else if (uinput == "4")
            {
                Measuringtool();
            }
            else if (uinput == "5")
            {
                Cleaningtool();
            }
            else if (uinput == "6")
            {
                Paintingtool();
            }
            else if (uinput == "7")
            {
                Electronictool();
            }
            else if (uinput == "8")
            {
                Electricitytool();
            }
            else if (uinput == "9")
            {
                Automotivetool();
            }
            else if (uinput == "0")
            {
                staffmenu();
            }
            else { Console.WriteLine("Wrong input try again"); AddNewTool();}
        }

        public static void Gardeningtool()
        {

            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Gardening Tools+++++++++");
            Console.WriteLine("1.Line Trimmers");
            Console.WriteLine("2.Lawn Mowers");
            Console.WriteLine("3.Hand Tools");
            Console.WriteLine("4.Wheelbarrows");
            Console.WriteLine("5.Garden Power Tools");
            Console.WriteLine("0.Back to previous menu");
            Garden = Console.ReadLine();
            if (Garden == "0") { AddNewTool(); }
            else if (Garden == "1" || Garden == "2" || Garden == "3" || Garden == "4" || Garden == "5")
            {
                Console.Write("Please input the name: ");
                string name = Console.ReadLine();
                Console.Write("Please input the quantity: ");
                string quantity = Console.ReadLine();
                int q = int.Parse(quantity);
                Tool tool = new Tool(name, q,q);
                ToolLibrarySystem.add(tool);
            }
            else {Console.WriteLine("Wrong input try again"); Gardeningtool();}
        }

        public static void Flooringtool()
        {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Flooring Tools+++++++++");
                Console.WriteLine("1.Scrapers");
                Console.WriteLine("2.Floor Lasers");
                Console.WriteLine("3.Floor Levelling Tools");
                Console.WriteLine("4.Floor Levelling Materials");
                Console.WriteLine("5.Floor Hand Tools");
                Console.WriteLine("6.Tiling Tools");
                Console.WriteLine("0.Back to the previous menu");
                Floor = Console.ReadLine();
                
                if (Floor == "0") { AddNewTool(); }
                else if(Floor == "1" || Floor == "2" || Floor == "3" || Floor == "4" || Floor == "5" || Floor == "6")
                {
                Console.Write("Please input the name: ");
                string name = Console.ReadLine();
                Console.Write("Please input the quantity: ");
                string quantity = Console.ReadLine();
                int q = int.Parse(quantity);
                Tool tool = new Tool(name, q,q);
                ToolLibrarySystem.add(tool);
            }
                else { Console.WriteLine("Wrong input try again"); Flooringtool(); }

        }

        public static void Fencingtool()
        {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Fencing Tools+++++++++");
                Console.WriteLine("1.Hand Tools");
                Console.WriteLine("2.Electric Fencing");
                Console.WriteLine("3.Steel Fencing Tools");
                Console.WriteLine("4.Power Tools");
                Console.WriteLine("5.Fencing Accessories");
                Console.WriteLine("0.Back to previous menu");
                Fence = Console.ReadLine();
                if (Fence == "0") { AddNewTool(); }
                else if (Fence == "1"||Fence =="2"||Fence=="3"||Fence=="4"||Fence=="5") 
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else { Console.WriteLine("Wrong input try again"); Fencingtool(); }
        }

        public static void Measuringtool()
            {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Measuring Tools+++++++++");
                Console.WriteLine("1.Distance Tools");
                Console.WriteLine("2.Laser Measurer");
                Console.WriteLine("3.Measuring Jugs");
                Console.WriteLine("4.Temperature & Humidity Tools");
                Console.WriteLine("5.Levelling Tools");
                Console.WriteLine("6.Markers");
                Console.WriteLine("0.Back to the previous menu");
                Measure = Console.ReadLine();
                if (Measure == "1" || Measure == "2"|| Measure=="3" || Measure=="4"||Measure=="5"||Measure=="6") 
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else if (Measure == "0") { AddNewTool(); }
                else { Console.WriteLine("Wrong input try again"); Measuringtool(); }
            }

        public static void Cleaningtool()
        {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Cleaning Tools+++++++++");
                Console.WriteLine("1.Draining");
                Console.WriteLine("2.Car Cleaning");
                Console.WriteLine("3.Vacuum");
                Console.WriteLine("4.Pressure Cleaners");
                Console.WriteLine("5.Pool Cleaning");
                Console.WriteLine("6.Floor Cleaning");
                Console.WriteLine("0.Back to the previous menu");
                Clean = Console.ReadLine();
                if (Clean == "0") { AddNewTool(); }
                else if(Clean == "1" || Clean=="2"||Clean=="3"||Clean=="4"||Clean=="5"||Clean=="6")
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else { Console.WriteLine("Wrong input try again"); Cleaningtool(); }
        }

        public static void Paintingtool()
            {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Painting Tools+++++++++");
                Console.WriteLine("1.Sanding Tools");
                Console.WriteLine("2.Brushes");
                Console.WriteLine("3.Rollers");
                Console.WriteLine("4.Paint Removal Tools");
                Console.WriteLine("5.Paint Scrapers");
                Console.WriteLine("6.Sprayers");
                Console.WriteLine("0.Back to the previous menu");
                Paint = Console.ReadLine();
                if (Paint == "0") { AddNewTool(); }
                else if (Paint =="1"||Paint=="2"||Paint=="3"||Paint=="4"||Paint=="5"||Paint=="6")
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else { Console.WriteLine("Wrong input try again"); Paintingtool(); }
            }

        public static void Electronictool()
            {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Electronic Tools+++++++++");
                Console.WriteLine("1.Voltage Tester");
                Console.WriteLine("2.Oscilloscopes");
                Console.WriteLine("3.Thermal Imaging");
                Console.WriteLine("4.Data Test Tool");
                Console.WriteLine("5.Insulation Testers");
                Console.WriteLine("0.Back to previous menu");
                Electron = Console.ReadLine();
                if (Electron == "0") { AddNewTool(); }
                else if (Electron == "1"||Electron=="2"||Electron=="3"||Electron=="4"||Electron=="5")   
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else { Console.WriteLine("Wrong input try again"); Electronictool(); }
        }

        public static void Electricitytool()
        {

                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Electricity Tools+++++++++");
                Console.WriteLine("1.Test Equipment");
                Console.WriteLine("2.Safety Equipment");
                Console.WriteLine("3.Basic Hand tools");
                Console.WriteLine("4.Circuit Protection");
                Console.WriteLine("5.Cable Tools");
                Console.WriteLine("0.Back to previous menu");
                Electricity = Console.ReadLine();
                if (Electricity == "0") { AddNewTool(); }
                else if(Electricity == "1" || Electricity == "2" || Electricity == "3" || Electricity == "4" || Electricity == "5")
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else { Console.WriteLine("Wrong input try again"); Electricitytool(); }
        }

        public static void Automotivetool()
        {
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Automotive Tools+++++++++");
                Console.WriteLine("1.Jacks");
                Console.WriteLine("2.Air Compressors");
                Console.WriteLine("3.Battery Chargers");
                Console.WriteLine("4.Socket Tools");
                Console.WriteLine("5.Braking");
                Console.WriteLine("6.Drivetrain");
                Console.WriteLine("0.Back to the previous menu");
                Automative = Console.ReadLine();
                if (Automative == "0") { AddNewTool(); }
                else if(Automative == "1" || Automative == "2" || Automative == "3" || Automative == "4" || Automative == "5" || Automative == "6")
                {
                    Console.Write("Please input the name: ");
                    string name = Console.ReadLine();
                    Console.WriteLine("Please input the quantity: ");
                    string quantity = Console.ReadLine();
                    int q = int.Parse(quantity);
                    Tool tool = new Tool(name, q,q);
                    ToolLibrarySystem.add(tool);
                }
                else { Console.WriteLine("Wrong input try again"); Automotivetool(); }
        }

        public static void AddNewpiece()
            {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Add New Pieces+++++++++");
                Console.WriteLine("1.Gardening tools");
                Console.WriteLine("2.Flooring tools");
                Console.WriteLine("3.Fencing tools");
                Console.WriteLine("4.Measuring tools");
                Console.WriteLine("5.Cleaning tools");
                Console.WriteLine("6.Painting tools");
                Console.WriteLine("7.Electronic tools");
                Console.WriteLine("8.Electricity tools");
                Console.WriteLine("9.Automotive tools");
                Console.WriteLine("0.Back to previous menu");

                Addinput = Console.ReadLine();

                if (Addinput == "0") { staffmenu(); }
                else if (Addinput == "1"|| Addinput == "2" || Addinput == "3" || Addinput == "4" || Addinput == "5" || Addinput == "6" || Addinput == "7" || Addinput == "8" || Addinput == "9" ) 
                {
                    Console.Write("Tool name: ");
                    string n= Console.ReadLine();
                    Console.Write("Quantity to add: ");
                    string q = Console.ReadLine();
                    int qu = int.Parse(q);
                    Tool name = new Tool(n);
                    ToolLibrarySystem.add(name, qu);
                }
            
                else {Console.WriteLine("Wrong input try again"); AddNewpiece(); }
            }

        public static void Removetool()
            {
                
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Remove Pieces+++++++++");
                Console.WriteLine("1.Gardening tools");
                Console.WriteLine("2.Flooring tools");
                Console.WriteLine("3.Fencing tools");
                Console.WriteLine("4.Measuring tools");
                Console.WriteLine("5.Cleaning tools");
                Console.WriteLine("6.Painting tools");
                Console.WriteLine("7.Electronic tools");
                Console.WriteLine("8.Electricity tools");
                Console.WriteLine("9.Automotive tools");
                Console.WriteLine("0.Back to previous menu");

                Deletinput= Console.ReadLine();
                if (Deletinput == "0") { staffmenu(); }
                else if(Deletinput == "1"|| Deletinput == "2" || Deletinput == "3" || 
                Deletinput == "4" || Deletinput == "5" || Deletinput == "6" || 
                Deletinput == "7" || Deletinput == "8" || Deletinput == "9" )
                     {
                        Console.Write("Tool name: ");
                        string n = Console.ReadLine();
                        Console.Write("Quantity to delet: ");
                        string q = Console.ReadLine();
                        int qu = int.Parse(q);
                        Tool name = new Tool(n,qu,qu);
                        ToolLibrarySystem.delete(name, qu);
                     }                
                else {Console.WriteLine("Wrong input try again"); Removetool(); }
            }

        public static void Registermember()
        {
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Register member+++++++++");
            Console.Write("Lastname: ");
            string Lname = Console.ReadLine();
            Console.Write("Firstname: ");
            string Fname = Console.ReadLine();
            Console.Write("Contact number: ");
            string phone = Console.ReadLine();
            Member member =new Member(Fname, Lname, phone, phone);
            if (ToolLibrarySystem.MEMCOLL.search(member) == true)
            {
                Console.WriteLine("Member exist.");
                Console.WriteLine("Push space to go back");
            if (Console.ReadKey().Key == ConsoleKey.Spacebar) { staffmenu(); }
            }
            ToolLibrarySystem.MEMCOLL.add(member);
            Console.WriteLine("successfully added");
            Console.WriteLine("Push space to go back");
            if (Console.ReadKey().Key == ConsoleKey.Spacebar) { staffmenu(); }
        }

        public static void Removemember()
        {
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Remove member+++++++++");
                Console.Write("Lastname: ");
                string Lname = Console.ReadLine();
                Console.Write("Firstname: ");
                string Fname = Console.ReadLine();
                Member member = new Member(Fname, Lname, null, null);
                if (ToolLibrarySystem.MEMCOLL.search(member) == true)
                {
                    ToolLibrarySystem.MEMCOLL.delete(member);
                    Console.WriteLine("Push space to go back");
                    if (Console.ReadKey().Key == ConsoleKey.Spacebar) { staffmenu(); }
                }
                Console.WriteLine("No member found");
                Console.WriteLine("Push space to go back");
                if (Console.ReadKey().Key == ConsoleKey.Spacebar) { staffmenu(); }

        }

        public static void Findphone()
        {
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Find Phone number+++++++++");
                Console.Write("Lastname: ");
                string Lname = Console.ReadLine();
                Console.Write("Firstname: ");
                string Fname = Console.ReadLine();
                Member member = new Member(Fname, Lname, null, null);
                if (ToolLibrarySystem.MEMCOLL.search(member) == true)
                {
                    Member[] X = new Member[ToolLibrarySystem.MEMCOLL.Number];
                    X=ToolLibrarySystem.MEMCOLL.toArray();
                    for (int i =0; i< X.Length; i++)
                    {
                    if (X[i].CompareTo(member)==0)
                    {
                        Console.WriteLine("Phone number: " + X[i].ContactNumber);
                        break;
                    }
                    }
                    
                    Console.WriteLine("Push space to go back");
                    if (Console.ReadKey().Key == ConsoleKey.Spacebar) { staffmenu(); }
                }
                Console.WriteLine("No such member");
                Console.WriteLine("Push space to go back");
                if (Console.ReadKey().Key == ConsoleKey.Spacebar) { staffmenu(); }

        }






    }

}

