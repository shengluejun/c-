﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class MemberCollection : iMemberCollection
    {
        private int number;
        
        private BSTree MBSTree ;
        private Member[] me;
        public Member[] ME => me;
        
       
        public int Number => number;

        public  MemberCollection()
        {
            MBSTree = new BSTree();
            me = new Member[100];
        }
        public void add(Member member)
        {
            
            MBSTree.Insert(member);
            me[number] = member;
            number++;
            
        }

        public void delete(Member member)
        {

            MBSTree.Delete(member);
            for(int i = 0; i < number; i++)
            {
                if (me[i] == member)
                {
                    for(int j = i + 1; j < number; j++)
                    {
                        me[j - 1] = me[j];
                    }
                }
            }
            number--;
        }

        public bool search(Member member)
        {
            
            bool a = MBSTree.Search(member);
            return a;
        }

        public Member[] toArray()
        {
            
            return me;
            
        }
    }
}
