﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class ToolCollection : iToolCollection
    {
        
        private int maxq = 30;
        private int count=0;
        private Tool[] tools;

        public int Number => count;

        public ToolCollection()
        {
            tools = new Tool[maxq];
            
        }

        public void add(Tool tool)
        {
            tools[count] = tool;
            count++;
        }

        public void delete(Tool tool)
        {
            int i = 0;
            while ((i < count) && (tool.Name.CompareTo(tools[i].Name) != 0))
                i++;
            if (i == count)
                Console.WriteLine("The tool does not exist!");
            else
            {
                for (int j = i + 1; j < count; j++)
                    tools[j - 1] = tools[j];
                count--;
            }
        }

        public bool search(Tool tool)
        {
            for(int i =0; i < count; i++)
            {
                if (tools[i].Name.CompareTo(tool.Name) != 0) { return false; }
            }
            return true;
        }

        public Tool[] toArray()
        {
            
            return tools;
        }
    }
}
