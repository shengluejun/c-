﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class Tool : iTool
    {
        
        private string name;
        private int quantity = 5, availablequantity=5;
        private int noborrowings=0;
        private Member[] me;
        private Tool atool;
        private MemberCollection collet;

        public string Name { get => name; set => name=value; }
        public int Quantity { get => quantity; set => quantity=value; }
        public int AvailableQuantity { get => availablequantity; set => availablequantity = value; }
        public int NoBorrowings { get => noborrowings; set => noborrowings=value; }
        public Tool(string na, int quan, int ava)
        {
            name=na;
            quantity=quan;
            availablequantity=ava;   
        }

        public Tool(string na, int avai)
        {
            name=na;
            availablequantity=avai;
        }

        public Tool (Tool tool) { atool=tool; me = new Member[20]; }
        
        public Tool(string name) { this.name = name; }

        public MemberCollection GetBorrowers => collet;

        public void addBorrower(Member member)
        {
            Member amember = new Member(member);
            me[noborrowings] = member;
            noborrowings++;
            availablequantity--;   
        }

        public void deleteBorrower(Member member)
        {
            Member amember = new Member(member);
            int i = 0;
            while ((i < noborrowings) && (me[i].CompareTo(member) != 0))
                i++;
            if (i == noborrowings)
                Console.WriteLine("The customer does not exist!");
            else
            {
                for (int j = i + 1; j < noborrowings; j++)
                    me[j - 1] = me[j];
                noborrowings--;
            }
            availablequantity++;
        }

        public override string ToString()
        {
            return name+" "+ quantity+" "+availablequantity+"\n";
        }
    }
}
