﻿using System;

namespace Assignment
{
    public class Program
    {
        private static string firstname, lastname, password;
        private static ToolLibrarySystem ToolLibrarySystem = new ToolLibrarySystem();
        public static string FIRSTNAME => firstname;
        public static string LASTNAME => lastname;
        public static string PASSWORD => password;
        static void Main(string[] args)
        {
            MainMenu();
        }
        public static void MainMenu()
        {
            string uinput;
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Main Menu+++++++++");
            Console.WriteLine("1. Member Login");
            Console.WriteLine("2. Staff Login");
            Console.WriteLine("0. Exit");
            Console.WriteLine("==========Please input here==========");
            uinput = Console.ReadLine();
            if (uinput == "1")
            {
                Membercheck();
            }
            else if (uinput == "2")
            {
                Staffcheck();
            }
            else if (uinput == "0")
            {
                EXIT();
            }
            else
            {
                Console.WriteLine("Input out of range, please re-do");
                MainMenu();
            }
        }
        public static void EXIT()
        {
            Environment.Exit(0);
        }

        public static void Membercheck()
        {
            
            Console.Write("Firstname: ");
            firstname = Console.ReadLine();
            Console.Write("Lastname: ");
            lastname = Console.ReadLine();
            Console.Write("Password: ");
            password = Console.ReadLine();
            Member member = new Member(firstname, lastname, password, null);
            if (ToolLibrarySystem.MEMCOLL.search(member)==true)
            {
                Membermenu.membermenu();
            }
            Console.WriteLine("NO SUCH MEMBER");
            MainMenu();


        }
        
        public static void Staffcheck()
        {
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Password: ");
            string password = Console.ReadLine();
            if (name == "staff" && password == "today123")
            {
                Staffmenu.staffmenu();
            }
            Console.WriteLine("No such staff");
            MainMenu();
        }
        
    }
}
