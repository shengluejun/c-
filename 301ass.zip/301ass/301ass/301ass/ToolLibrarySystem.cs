﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment
{
    public class ToolLibrarySystem : iToolLibrarySystem
    {
        private MemberCollection memcoll ;

        private ToolCollection[] gardening;
        private ToolCollection[] flooring;
        private ToolCollection[] measuring;
        private ToolCollection[] fencening;
        private ToolCollection[] cleaning;
        private ToolCollection[] painting;
        private ToolCollection[] electronic;
        private ToolCollection[] electricity;
        private ToolCollection[] automotive;

        private ToolCollection LT = new ToolCollection();
        private ToolCollection LM = new ToolCollection();
        private ToolCollection HT = new ToolCollection();
        private ToolCollection GPT = new ToolCollection();
        private ToolCollection WHEEL = new ToolCollection();

        private ToolCollection Scra = new ToolCollection();
        private ToolCollection Laser = new ToolCollection();
        private ToolCollection Leveltool = new ToolCollection();
        private ToolCollection LevelMaterial = new ToolCollection();
        private ToolCollection FH = new ToolCollection();
        private ToolCollection TT = new ToolCollection();

        private ToolCollection HTF = new ToolCollection();
        private ToolCollection EF = new ToolCollection();
        private ToolCollection SFT = new ToolCollection();
        private ToolCollection PT = new ToolCollection();
        private ToolCollection FA = new ToolCollection();

        private ToolCollection DT = new ToolCollection();
        private ToolCollection LMM = new ToolCollection();
        private ToolCollection MJ = new ToolCollection();
        private ToolCollection THT = new ToolCollection();
        private ToolCollection LTM = new ToolCollection();
        private ToolCollection Markers = new ToolCollection();

        private ToolCollection Draining = new ToolCollection();
        private ToolCollection CC = new ToolCollection();
        private ToolCollection Vaccum = new ToolCollection();
        private ToolCollection PC = new ToolCollection();
        private ToolCollection Pool = new ToolCollection();
        private ToolCollection FC = new ToolCollection();

        private ToolCollection ST = new ToolCollection();
        private ToolCollection Brushes = new ToolCollection();
        private ToolCollection Rollers = new ToolCollection();
        private ToolCollection PRT = new ToolCollection();
        private ToolCollection PS = new ToolCollection();
        private ToolCollection Sprayers = new ToolCollection();

        private ToolCollection VT = new ToolCollection();
        private ToolCollection Oscilloscopes = new ToolCollection();
        private ToolCollection TI = new ToolCollection();
        private ToolCollection DTT = new ToolCollection();
        private ToolCollection IT = new ToolCollection();

        private ToolCollection TE = new ToolCollection();
        private ToolCollection SE = new ToolCollection();
        private ToolCollection BH = new ToolCollection();
        private ToolCollection CP = new ToolCollection();
        private ToolCollection CT = new ToolCollection();

        private ToolCollection Jacks = new ToolCollection();
        private ToolCollection AC = new ToolCollection();
        private ToolCollection BC = new ToolCollection();
        private ToolCollection STA = new ToolCollection();
        private ToolCollection Braking = new ToolCollection();
        private ToolCollection Drivetrain = new ToolCollection();

        private int nummem=0, numtool=0;
        private string[] listool;
        private string[] topthree;
        private int num;
        public MemberCollection MEMCOLL => memcoll;
       
        public ToolLibrarySystem()
        {
            
            memcoll = new MemberCollection();
            gardening = new ToolCollection[100];
            flooring = new ToolCollection[100];
            measuring = new ToolCollection[100];
            fencening = new ToolCollection[100];
            cleaning = new ToolCollection[100];
            painting = new ToolCollection[100];
            electronic = new ToolCollection[100];
            electricity = new ToolCollection[100];
            automotive = new ToolCollection[100];

            //test = new Member();
        }
        
        public void add(Tool tool)
        {
            if(Staffmenu.GARDEN == "1") 
            {
                
                LT.add(tool);
                gardening[0] = LT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.GARDEN == "2") 
            {
                
                LM.add(tool);
                gardening[1] = LM;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.GARDEN == "3") 
            {
                
                HT.add(tool);
                gardening[2] = HT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.GARDEN == "4") 
            {
                
                WHEEL.add(tool);
                gardening[3] = WHEEL;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.GARDEN == "5") 
            {
                
                GPT.add(tool);
                gardening[4] = GPT;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if (Staffmenu.FLOOR == "1") 
            {
               
                Scra.add(tool);
                flooring[0] = Scra;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FLOOR == "2") 
            {
                
                Laser.add(tool);
                flooring[1] = Laser;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FLOOR == "3") 
            {
                
                Leveltool.add(tool);
                flooring[2] = Leveltool;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FLOOR == "4") 
            {
                
                LevelMaterial.add(tool);
                flooring[3] = LevelMaterial;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FLOOR == "5") 
            {
                
                FH.add(tool);
                flooring[4] = FH;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FLOOR == "6") 
            {
               
                TT.add(tool);
                flooring[5] = TT;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if (Staffmenu.FENCE == "1")
            {
                
                HTF.add(tool);
                fencening[0] = HTF;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FENCE == "2")
            {
                
                EF.add(tool);
                fencening[1] = EF;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FENCE == "3")
            {
                
                SFT.add(tool);
                fencening[2] = SFT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FENCE == "4")
            {
                
                PT.add(tool);
                fencening[3] = PT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.FENCE == "5")
            {
                
                FA.add(tool);
                fencening[4] = FA;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if(Staffmenu.MEASURE == "1")
            {
               
                DT.add(tool);
                measuring[0] = DT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.MEASURE == "2")
            {
                
                LMM.add(tool);
                measuring[1] = LMM;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.MEASURE == "3")
            {
                
                MJ.add(tool);
                measuring[2] = MJ;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.MEASURE == "4")
            {
                
                THT.add(tool);
                measuring[3] = THT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.MEASURE == "5")
            {
                
                LTM.add(tool);
                measuring[4] = LTM;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.MEASURE == "6")
            {
                
                Markers.add(tool);
                measuring[5] = Markers;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if(Staffmenu.CLEAN == "1")
            {
                
                Draining.add(tool);
                cleaning[0] = Draining;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.CLEAN == "2")
            {
                
                CC.add(tool);
                cleaning[1] = CC;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.CLEAN == "3")
            {
                
                Vaccum.add(tool);
                cleaning[2] = Vaccum;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.CLEAN == "4")
            {
                
                PC.add(tool);
                cleaning[3] = PC;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.CLEAN == "5")
            {
                
                Pool.add(tool);
                cleaning[4] = Pool;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.CLEAN == "6")
            {
                
                FC.add(tool);
                cleaning[5] = FC;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if (Staffmenu.PAINT == "1")
            {
                
                ST.add(tool);
                painting[0] = ST;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.PAINT == "2")
            {
                
                Brushes.add(tool);
                painting[1] = Brushes;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.PAINT == "3")
            {
                
                Rollers.add(tool);
                painting[2] = Rollers;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.PAINT == "4")
            {
                
                PRT.add(tool);
                painting[3] = PRT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.PAINT == "5")
            {
                
                PS.add(tool);
                painting[4] = PS;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.PAINT == "6")
            {
                
                Sprayers.add(tool);
                painting[5] = Sprayers;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if(Staffmenu.ELECTRON == "1") 
            {
                
                VT.add(tool);
                electronic[0] = VT;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRON == "2")
            {
                
                Oscilloscopes.add(tool);
                electronic[1] = Oscilloscopes;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRON == "3")
            {
                
                TI.add(tool);
                electronic[2] = TI;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRON == "4")
            {
                
                DTT.add(tool);
                electronic[3] = DTT; 
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRON == "5")
            {
                
                IT.add(tool);
                electronic[4] = IT;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if (Staffmenu.ELECTRICITY=="1")
            {
                
                TE.add(tool);
                electricity[0] = TE;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRICITY == "2")
            {
                
                SE.add(tool);
                electricity[1] = SE;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRICITY == "3")
            {
                
                BH.add(tool);
                electricity[2] = BH;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRICITY == "4")
            {
                
                CP.add(tool);
                electricity[3] = CP;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.ELECTRICITY == "5")
            {
                
                CT.add(tool);
                electricity[4] = CT;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else if (Staffmenu.AUTOMATIVE=="1")
            {
                
                Jacks.add(tool);
                automotive[0] = Jacks;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.AUTOMATIVE == "2")
            {
                
                AC.add(tool);
                automotive[1] = AC;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.AUTOMATIVE == "3")
            {
                
                BC.add(tool);
                automotive[2] = BC;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.AUTOMATIVE == "4")
            {
                
                STA.add(tool);
                automotive[3] = STA;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.AUTOMATIVE == "5")
            {
                
                Braking.add(tool);
                automotive[4] = Braking;
                numtool++;
                Staffmenu.AddNewTool();
            }
            else if (Staffmenu.AUTOMATIVE == "6")
            {
                
                Drivetrain.add(tool);
                automotive[5] = Drivetrain;
                numtool++;
                Staffmenu.AddNewTool();
            }

            else { Console.WriteLine("Wrong input try again"); }
            
        }

        public void add(Tool tool, int quantity)
        {
            if (Staffmenu.ADDINPUT == "1")
            {
                for (int i = 0; i < gardening.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (gardening[i].search(tool) == true) 
                        { 
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else {Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();
            }
            if (Staffmenu.ADDINPUT == "2")
            {
                for (int i = 0; i < flooring.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (flooring[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "3")
            {
                for (int i = 0; i < fencening.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (fencening[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "4")
            {
                for (int i = 0; i < measuring.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (measuring[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "5")
            {
                for (int i = 0; i < cleaning.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (cleaning[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "6")
            {
                for (int i = 0; i < painting.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (painting[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "7")
            {
                for (int i = 0; i < electronic.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (electronic[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "8")
            {
                for (int i = 0; i < electricity.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (electricity[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }
            if (Staffmenu.ADDINPUT == "9")
            {
                for (int i = 0; i < automotive.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (automotive[i].search(tool) == true)
                        {
                            tool.Quantity += quantity;
                            Console.WriteLine("Successfully added.");
                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Staffmenu.AddNewpiece();

            }

        }

        public void add(Member member)
        {
           memcoll.add(member);
            nummem++;
        }

        public void borrowTool(Member member, Tool tool)
        {
            member.addTool(tool);
            tool.addBorrower(member);
            topthree[num]=tool.Name;
            num++;
        }

        public void delete(Tool tool)
        {
            if (Staffmenu.DELETINPUT == "1")
            {
                for (int i = 0; i < gardening.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        gardening[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "2")
            {
                for (int i = 0; i < flooring.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        flooring[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "3")
            {
                for (int i = 0; i < fencening.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        fencening[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "4")
            {
                for (int i = 0; i < measuring.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        measuring[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "5")
            {
                for (int i = 0; i < cleaning.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        cleaning[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "6")
            {
                for (int i = 0; i < painting.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        painting[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "7")
            {
                for (int i = 0; i < electronic.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        electronic[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "8")
            {
                for (int i = 0; i < electricity.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        electricity[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "9")
            {
                for (int i = 0; i < automotive.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        automotive[i].delete(tool);
                    }
                }
                numtool -= tool.Quantity;
                Console.WriteLine("Successfully deleted.");
                Staffmenu.Removetool();
            }
        }

        public void delete(Tool tool, int quantity)
        {
            if (Staffmenu.DELETINPUT == "1")
            {
                for (int i = 0; i < gardening.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (gardening[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            if (tool.AvailableQuantity - quantity < 0) { tool.AvailableQuantity = 0; }
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "2")
            {
                for (int i = 0; i < flooring.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (flooring[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "3")
            {
                for (int i = 0; i < fencening.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (fencening[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "4")
            {
                for (int i = 0; i < measuring.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (measuring[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool);  }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "5")
            {
                for (int i = 0; i < cleaning.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (cleaning[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "6")
            {
                for (int i = 0; i < painting.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (painting[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "7")
            {
                for (int i = 0; i < electronic.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (electronic[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "8")
            {
                for (int i = 0; i < electricity.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (electricity[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
                
                Staffmenu.Removetool();
            }
            if (Staffmenu.DELETINPUT == "9")
            {
                for (int i = 0; i < automotive.Length; i++)
                {
                    for (int j = 0; i < numtool; j++)
                    {
                        if (automotive[i].search(tool) == true)
                        {
                            tool.Quantity -= quantity;
                            numtool -= quantity;
                            if (tool.Quantity == 0) { delete(tool); }
                            Console.WriteLine("Successfully deleteded.");

                        }
                        else { Console.WriteLine("NO such tool"); }
                        break;
                    }
                }
                Console.WriteLine("Successfully deleted.");
               
                Staffmenu.Removetool();
            }
        }

        public void delete(Member member)
        {
            memcoll.delete(member);
            nummem--;
        }

        public void display(Member member)
        {
            if(memcoll.search(member) == true)
            {
                for(int i = 0; i< 3; i++)
                {
                    string a = member.Tools[i];
                    Console.WriteLine("Current renting tools: " + a);
                }
            }
            Console.WriteLine("No tools are renting.");
        }

        public void displayTools(string tooltype)
        {
            
            if(tooltype == "Line Trimmers" && Membermenu.MINPUT=="1") { gardening[0].toArray();}
            else if (tooltype == "Lawn Mowers" && Membermenu.MINPUT == "1") { gardening[1].toArray(); }
            else if (tooltype == "Hand Tools" && Membermenu.MINPUT == "1") { gardening[2].toArray(); }
            else if (tooltype == "Wheelbarrows" && Membermenu.MINPUT == "1") { gardening[3].toArray(); }
            else if (tooltype == "Garden Power Tools" && Membermenu.MINPUT == "1") { gardening[4].toArray(); }

            else if (tooltype == "Scrapers" && Membermenu.MINPUT == "2") { flooring[0].toArray(); }
            else if (tooltype == "Floor Lasers" && Membermenu.MINPUT == "2") { flooring[1].toArray(); }
            else if (tooltype == "Floor Levelling Tools" && Membermenu.MINPUT == "2") { flooring[2].toArray(); }
            else if (tooltype == "Floor Levelling Materials" && Membermenu.MINPUT == "2") { flooring[3].toArray(); }
            else if (tooltype == "Floor Hand Tools" && Membermenu.MINPUT == "2") { flooring[4].toArray(); }
            else if (tooltype == "Tiling Tools" && Membermenu.MINPUT == "2") { flooring[5].toArray(); }

            else if (tooltype == "Hand Tools" && Membermenu.MINPUT == "3") { fencening[0].toArray(); }
            else if (tooltype == "Electric Fencing" && Membermenu.MINPUT == "3") { fencening[1].toArray(); }
            else if (tooltype == "Steel Fencing Tools" && Membermenu.MINPUT == "3") { fencening[2].toArray(); }
            else if (tooltype == "Power Tools" && Membermenu.MINPUT == "3") { fencening[3].toArray(); }
            else if (tooltype == "Fencing Accessories" && Membermenu.MINPUT == "3") { fencening[4].toArray(); }

            else if (tooltype == "Distance Tools" && Membermenu.MINPUT == "4") { measuring[0].toArray(); }
            else if (tooltype == "Laser Measurer" && Membermenu.MINPUT == "4") { measuring[1].toArray(); }
            else if (tooltype == "Measuring Jugs" && Membermenu.MINPUT == "4") { measuring[2].toArray(); }
            else if (tooltype == "Temperature & Humidity Tools" && Membermenu.MINPUT == "4") { measuring[3].toArray(); }
            else if (tooltype == "Levelling Tools" && Membermenu.MINPUT == "4") { measuring[4].toArray(); } 
            else if (tooltype == "Markers" && Membermenu.MINPUT == "4") { measuring[5].toArray(); }

            else if (tooltype == "Draining" && Membermenu.MINPUT == "5") { cleaning[0].toArray(); }
            else if (tooltype == "Car Cleaning" && Membermenu.MINPUT == "5") { cleaning[1].toArray(); }
            else if (tooltype == "Vacuum" && Membermenu.MINPUT == "5") { cleaning[2].toArray(); }
            else if (tooltype == "Pressure Cleaners" && Membermenu.MINPUT == "5") { cleaning[3].toArray(); }
            else if (tooltype == "Pool Cleaning" && Membermenu.MINPUT == "5") { cleaning[4].toArray(); }
            else if (tooltype == "Floor Cleaning" && Membermenu.MINPUT == "5") { cleaning[5].toArray(); }

            else if (tooltype == "Sanding Tools" && Membermenu.MINPUT == "6") { painting[0].toArray(); }
            else if (tooltype == "Brushes" && Membermenu.MINPUT == "6") { painting[1].toArray(); }
            else if (tooltype == "Rollers" && Membermenu.MINPUT == "6") { painting[2].toArray(); }
            else if (tooltype == "Paint Removal Tools" && Membermenu.MINPUT == "6") { painting[3].toArray(); }
            else if (tooltype == "Paint Scrapers" && Membermenu.MINPUT == "6") { painting[4].toArray(); }
            else if (tooltype == "Sprayers" && Membermenu.MINPUT == "6") { painting[5].toArray(); }

            else if (tooltype == "Voltage Tester" && Membermenu.MINPUT == "7") { electronic[0].toArray(); }
            else if (tooltype == "Oscilloscopes" && Membermenu.MINPUT == "7") { electronic[1].toArray(); }
            else if (tooltype == "Thermal Imaging" && Membermenu.MINPUT == "7") { electronic[2].toArray(); }
            else if (tooltype == "Data Test Tool" && Membermenu.MINPUT == "7") { electronic[3].toArray(); }
            else if (tooltype == "Insulation Testers" && Membermenu.MINPUT == "7") { electronic[4].toArray(); }

            else if (tooltype == "Test Equipment" && Membermenu.MINPUT == "8") { electricity[0].toArray(); }
            else if (tooltype == "Safety Equipment" && Membermenu.MINPUT == "8") { electricity[1].toArray(); }
            else if (tooltype == "Basic Hand tools" && Membermenu.MINPUT == "8") { electricity[2].toArray(); }
            else if (tooltype == "Circuit Protection" && Membermenu.MINPUT == "8") { electricity[3].toArray(); }
            else if (tooltype == "Cable Tools" && Membermenu.MINPUT == "8") { electricity[4].toArray(); }

            else if (tooltype == "Jacks" && Membermenu.MINPUT == "9") { automotive[0].toArray(); }
            else if (tooltype == "Air Compressors" && Membermenu.MINPUT == "9") { automotive[1].toArray(); }
            else if (tooltype == "Battery Chargers" && Membermenu.MINPUT == "9") { automotive[2].toArray(); }
            else if (tooltype == "Socket Tools" && Membermenu.MINPUT == "9") { automotive[3].toArray(); }
            else if (tooltype == "Braking" && Membermenu.MINPUT == "9") { automotive[4].toArray(); }
            else if (tooltype == "Drivetrain" && Membermenu.MINPUT == "9") { automotive[5].toArray(); }

            else { Console.WriteLine("Wrong input try again"); }
        }

        public void displayTopTHree()
        {
            string[] a = new string[3];
            a = topthree.GroupBy(x => x).OrderByDescending(x => x.Count()).Take(3).Select(x => x.Key).ToArray();
            Console.WriteLine("The most three popular tools are: " + a);
        }

        public string[] listTools(Member member) 
        {
            if (memcoll.search(member) == true)
            {
                for (int i = 0; i < 3; i++)
                {
                    string a = member.Tools[i];
                    listool[i] = a;
                }
                
            }
            Console.WriteLine("No such member.");
            if (listool == null) { Console.WriteLine("No tool borrowed"); }
            return listool;

        }

        public void returnTool(Member member, Tool tool)
        {
            member.deleteTool(tool);
            tool.deleteBorrower(member);
        }
    }
}
