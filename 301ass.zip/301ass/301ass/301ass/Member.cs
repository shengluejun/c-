﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Assignment
{
    public class Member : iMember, IComparable<Member>
    {
        private string firstname, lastname, contactnumber, pin;
        private string[] tools ;
        private int count = 0;

        private Member member;


        public string FirstName { get => firstname; set => firstname = value; }
        public string LastName { get => lastname; set => lastname = value; }
        public string ContactNumber { get => contactnumber; set => contactnumber = value; }
        public string PIN { get => pin; set => pin = value; }

        public string[] Tools => tools;

        public Member (string fi, string la, string mo, string pass)
        {
            firstname=fi;
            lastname=la;
            contactnumber=mo;
            pin=pass;
            tools = new string[10];
            
        }

        public Member(string fi, string la, string pass)
        {
            firstname=fi;
            lastname=la;
            pin=pass;
        }

        public Member(Member member) {  this.member = member; }

        public Member() { }

        public void addTool(Tool tool)
        {
            
            tools[count] = tool.Name;
            count++;
            if (count>3) { Console.WriteLine("Cannot hold over 3 tools"); }
        }

        public void deleteTool(Tool tool)
        {

            int i = 0;
            while ((i < count) && (tool.Name.CompareTo(tools[i]) != 0))
                i++;
            if (i == count)
                Console.WriteLine("The tool does not exist!");
            else
            {
                for (int j = i + 1; j < count; j++)
                    tools[j - 1] = tools[j];
                count--;
            }

        }

        public override string ToString()
        {

            return firstname+" "+lastname+" " +contactnumber+"\n";
        }

        public int CompareTo(Member obj)
        {
            
            if (this.lastname.CompareTo( obj.LastName) < 0)
                return -1;
            else
               if (this.lastname.CompareTo( obj.LastName) == 0)
                return this.firstname.CompareTo(obj.FirstName);
            else
                return 1;
        }
    }
}
