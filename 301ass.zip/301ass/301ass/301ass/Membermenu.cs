﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment
{
    public class Membermenu
    {
        private static ToolLibrarySystem ToolLibrary = new ToolLibrarySystem();

        private static string Minput;
        public static string MINPUT => Minput;
        public static void membermenu()
        {
            string uinput;
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Staff Menu+++++++++");
            Console.WriteLine("1. Display all the tools of a tool type");
            Console.WriteLine("2. Borrow a tool");
            Console.WriteLine("3. Return a tool");
            Console.WriteLine("4. List all the tools that I am renting");
            Console.WriteLine("5. Display top three most frequently rented tools");
            Console.WriteLine("0. Retrun to main menu");
            Console.WriteLine("==========Please input here==========");
            uinput = Console.ReadLine();
            if (uinput == "0") { Program.MainMenu();}
            else if (uinput == "1") { DisplayToolType(); }
            else if (uinput == "2") { BorrowTool(); }
            else if (uinput == "3") { Returntool(); }
            else if (uinput == "4") { DisplayTopThree(); }
            else if (uinput == "5") { Listtool(); }
            else { Console.WriteLine("Wrong input try again"); membermenu(); }
        }
        public static void DisplayToolType()
        {
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Display tools+++++++++");
            Console.WriteLine("1.Gardening tools");
            Console.WriteLine("2.Flooring tools");
            Console.WriteLine("3.Fencing tools");
            Console.WriteLine("4.Measuring tools");
            Console.WriteLine("5.Cleaning tools");
            Console.WriteLine("6.Painting tools");
            Console.WriteLine("7.Electronic tools");
            Console.WriteLine("8.Electricity tools");
            Console.WriteLine("9.Automotive tools");
            Console.WriteLine("0.Back to previous menu");
            Console.WriteLine("==========Please input here==========");
            Minput = Console.ReadLine();
            ToolLibrary = new ToolLibrarySystem();
            if (Minput=="0") { membermenu(); }
            else if (Minput == "1") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Garding tools+++++++++");
                Console.WriteLine("Line Trimmers");
                Console.WriteLine("Lawn Mowers");
                Console.WriteLine("Hand Tools");
                Console.WriteLine("Wheelbarrows");
                Console.WriteLine("Garden Power Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "2") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Flooring tools+++++++++");
                Console.WriteLine("Scrapers");
                Console.WriteLine("Floor Lasers");
                Console.WriteLine("Floor Levelling Tools");
                Console.WriteLine("Floor Levelling Materials");
                Console.WriteLine("Floor Hand Tools");
                Console.WriteLine("Tiling Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "3") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Fencing tools+++++++++");
                Console.WriteLine("Hand Tools");
                Console.WriteLine("Electric Fencing");
                Console.WriteLine("Steel Fencing Tools");
                Console.WriteLine("Power Tools");
                Console.WriteLine("Fencing Accessories");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "4") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Measuring tools+++++++++");
                Console.WriteLine("Distance Tools");
                Console.WriteLine("Laser Measurer");
                Console.WriteLine("Measuring Jugs");
                Console.WriteLine("Temperature & Humidity Tools");
                Console.WriteLine("Levelling Tools");
                Console.WriteLine("Markers");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "5") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Cleaning tools+++++++++");
                Console.WriteLine("Draining");
                Console.WriteLine("Car Cleaning");
                Console.WriteLine("Vacuum");
                Console.WriteLine("Pressure Cleaners");
                Console.WriteLine("Pool Cleaning");
                Console.WriteLine("Floor Cleaning");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "6") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Painting tools+++++++++");
                Console.WriteLine("Sanding Tools");
                Console.WriteLine("Brushes");
                Console.WriteLine("Rollers");
                Console.WriteLine("Paint Removal Tools");
                Console.WriteLine("Paint Scrapers");
                Console.WriteLine("Sprayers");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "7") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Electronic tools+++++++++");
                Console.WriteLine("Scrapers");
                Console.WriteLine("Floor Lasers");
                Console.WriteLine("Floor Levelling Tools");
                Console.WriteLine("Floor Levelling Materials");
                Console.WriteLine("Floor Hand Tools");
                Console.WriteLine("Tiling Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "8") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Electricity tools+++++++++");
                Console.WriteLine("Test Equipment");
                Console.WriteLine("Safety Equipment");
                Console.WriteLine("Basic Hand tools");
                Console.WriteLine("Circuit Protection");
                Console.WriteLine("Cable Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else if (Minput == "9") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Automative tools+++++++++");
                Console.WriteLine("Jacks");
                Console.WriteLine("Air Compressors");
                Console.WriteLine("Battery Chargers");
                Console.WriteLine("Socket Tools");
                Console.WriteLine("Braking");
                Console.WriteLine("Drivetrain");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
            }
            else { Console.WriteLine("Wrong input try again");  DisplayToolType(); }

        }

        public static void BorrowTool()
        {
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Display tools+++++++++");
            Console.WriteLine("1.Gardening tools");
            Console.WriteLine("2.Flooring tools");
            Console.WriteLine("3.Fencing tools");
            Console.WriteLine("4.Measuring tools");
            Console.WriteLine("5.Cleaning tools");
            Console.WriteLine("6.Painting tools");
            Console.WriteLine("7.Electronic tools");
            Console.WriteLine("8.Electricity tools");
            Console.WriteLine("9.Automotive tools");
            Console.WriteLine("0.Back to previous menu");
            Console.Write("Please choose category: ");
            Minput = Console.ReadLine();
            if (Minput == "0") { membermenu(); }
            else if (Minput == "1") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Garding tools+++++++++");
                Console.WriteLine("Line Trimmers");
                Console.WriteLine("Lawn Mowers");
                Console.WriteLine("Hand Tools");
                Console.WriteLine("Wheelbarrows");
                Console.WriteLine("Garden Power Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
                

            }
            else if (Minput == "2") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Flooring tools+++++++++");
                Console.WriteLine("Scrapers");
                Console.WriteLine("Floor Lasers");
                Console.WriteLine("Floor Levelling Tools");
                Console.WriteLine("Floor Levelling Materials");
                Console.WriteLine("Floor Hand Tools");
                Console.WriteLine("Tiling Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "3") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Fencing tools+++++++++");
                Console.WriteLine("Hand Tools");
                Console.WriteLine("Electric Fencing");
                Console.WriteLine("Steel Fencing Tools");
                Console.WriteLine("Power Tools");
                Console.WriteLine("Fencing Accessories");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "4") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Measuring tools+++++++++");
                Console.WriteLine("Distance Tools");
                Console.WriteLine("Laser Measurer");
                Console.WriteLine("Measuring Jugs");
                Console.WriteLine("Temperature & Humidity Tools");
                Console.WriteLine("Levelling Tools");
                Console.WriteLine("Markers");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "5") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Cleaning tools+++++++++");
                Console.WriteLine("Draining");
                Console.WriteLine("Car Cleaning");
                Console.WriteLine("Vacuum");
                Console.WriteLine("Pressure Cleaners");
                Console.WriteLine("Pool Cleaning");
                Console.WriteLine("Floor Cleaning");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "6") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Painting tools+++++++++");
                Console.WriteLine("Sanding Tools");
                Console.WriteLine("Brushes");
                Console.WriteLine("Rollers");
                Console.WriteLine("Paint Removal Tools");
                Console.WriteLine("Paint Scrapers");
                Console.WriteLine("Sprayers");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "7") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Electronic tools+++++++++");
                Console.WriteLine("Scrapers");
                Console.WriteLine("Floor Lasers");
                Console.WriteLine("Floor Levelling Tools");
                Console.WriteLine("Floor Levelling Materials");
                Console.WriteLine("Floor Hand Tools");
                Console.WriteLine("Tiling Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "8") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Electricity tools+++++++++");
                Console.WriteLine("Test Equipment");
                Console.WriteLine("Safety Equipment");
                Console.WriteLine("Basic Hand tools");
                Console.WriteLine("Circuit Protection");
                Console.WriteLine("Cable Tools");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else if (Minput == "9") 
            {
                string uinput;
                Console.WriteLine("==========Welcome to Tool Library==========");
                Console.WriteLine("++++++++++Automative tools+++++++++");
                Console.WriteLine("Jacks");
                Console.WriteLine("Air Compressors");
                Console.WriteLine("Battery Chargers");
                Console.WriteLine("Socket Tools");
                Console.WriteLine("Braking");
                Console.WriteLine("Drivetrain");
                Console.Write("please choose a tool type: ");
                uinput = Console.ReadLine();
                ToolLibrary.displayTools(uinput);
                Console.Write("Please choose a tool: ");
                string tool = Console.ReadLine();
                Tool tool1 = new Tool(tool, 1);
                Member member1 = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
                ToolLibrary.borrowTool(member1, tool1);
            }
            else { Console.WriteLine("Wrong input try again"); BorrowTool(); }
        }

        public static void Listtool()
        {
            Member member = new Member(Program.FIRSTNAME, Program.LASTNAME, Program.PASSWORD);
            ToolLibrary.listTools(member);
            if (member.Tools == null)
            {
                Console.WriteLine("No tool borrowed.");
                Console.WriteLine("Push space to go back");
                if (Console.ReadKey().Key == ConsoleKey.Spacebar) { membermenu(); }
            }
            Console.WriteLine("Push space to go back");
            if (Console.ReadKey().Key==ConsoleKey.Spacebar) { membermenu(); }
        }
        
        public static void Returntool()
        {
            Console.WriteLine("==========Welcome to Tool Library==========");
            Console.WriteLine("++++++++++Return tools+++++++++");
            Console.WriteLine("Choose the tool you want to return " );
            Listtool();
            Console.Write("Input: ");
            string uinput = Console.ReadLine();
            Member member = new Member(Program.FIRSTNAME, Program.FIRSTNAME, Program.PASSWORD);
            Tool tool = new Tool(uinput, 1);
            ToolLibrary.returnTool(member, tool);
            Console.WriteLine("Push space to go back");
            if (Console.ReadKey().Key == ConsoleKey.Spacebar) { membermenu(); }
        }

        public static void DisplayTopThree()
        {
            ToolLibrary.displayTopTHree();
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Push space to go back");
            if (Console.ReadKey().Key == ConsoleKey.Spacebar) { membermenu(); }

        }
    }
}
